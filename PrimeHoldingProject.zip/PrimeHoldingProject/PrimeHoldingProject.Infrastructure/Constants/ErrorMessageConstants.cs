﻿namespace PrimeHoldingProject.Infrastructure.Constants
{
    public static class ErrorMessageConstants
    {
            public const string NameErrorMessage = "{0} should be between {2} and {1} characters long";
            public const string PasswordErrorMessage = "{0} shouldn't be less than {2} characters long";
    }
}
