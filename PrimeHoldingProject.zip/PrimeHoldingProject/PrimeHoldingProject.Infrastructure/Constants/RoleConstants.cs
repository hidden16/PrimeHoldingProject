﻿namespace PrimeHoldingProject.Infrastructure.Constants
{
    public static class RoleConstants
    {
        public const string EmployeeConstant = "Employee";
        public const string ManagerConstant = "Manager";
    }
}
