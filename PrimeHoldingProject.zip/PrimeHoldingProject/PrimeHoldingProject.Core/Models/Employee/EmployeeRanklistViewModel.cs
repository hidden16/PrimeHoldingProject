﻿namespace PrimeHoldingProject.Core.Models.Employee
{
    public class EmployeeRanklistViewModel
    {
        public string FullName { get; set; }
        public int TasksDoneCount { get; set; }
    }
}
